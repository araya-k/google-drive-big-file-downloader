<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', '' );

/** MySQL database username */
define( 'DB_USER', '' );

/** MySQL database password */
define( 'DB_PASSWORD', '' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'B=mU]w~MDkK{II0|1lhY 10({GBOua4*d*G;SPOu?u|H9^hEN^Vz*p^{7!I[bpU_' );
define( 'SECURE_AUTH_KEY',  '?A%F*(2E1)C@!TzYSK85!Hih/1_x4s9wX/|8HpN&3a$:2~a;0C$A;1EhaT}j:cwD' );
define( 'LOGGED_IN_KEY',    '[#((D;p*rdO2#43  *Jc|.VO0Ql^fx/y_RQE[4{:r:f vGt4Z[.0;4XUQwj% .oA' );
define( 'NONCE_KEY',        '=wUeF_aL>zNe <HClz!Lu6&.NkH5yD+oi2!{kOC(eX@`W2kx^PL+xDFJoxR^NyhR' );
define( 'AUTH_SALT',        '2k_2:;OlDp5B@Tx[/T$$*fR_WelqI: rg.vXY8cGMOh_hEx#b6>M`wiUzi^Sk{?K' );
define( 'SECURE_AUTH_SALT', '_}Qo7EsxckpO%1SY*7Uu`!%PZ_wG]6VbBiYKQ;/Wi[[:w1;_LtyZ2<2JhCRzTk.?' );
define( 'LOGGED_IN_SALT',   'L(AJ]wrGuCk1quffel_o5pEprk<P:XG(d/3lcfR8lV~vRG1v}xt?!LEq~?:Ap[<_' );
define( 'NONCE_SALT',       '@2(r5w=V3*cbHd;e]IK,x<=T.PVCl<4j^]??Wv-tF$CSS@U?wxS+K9HQXt$G?(X7' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', true );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
